﻿namespace web_app_performance.Model
{
    public class Produto
    {

        public int Id { get; set; }
        public string Nome { get; set; }
        public double Preco { get; set; }
        public int QuantidadeEstoque { get; set; }
        public string DataCriacao { get; set; }
    }
}
